import React from 'react';
import { BarChart3, ShieldCheck, Truck } from 'lucide-react';

interface FeaturesProps {
  lang: 'fr' | 'en';
}

const Features: React.FC<FeaturesProps> = ({ lang }) => {
  const t = {
    fr: {
      title: "Pourquoi Vendre avec ",
      span: "TrustLink ?",
      subtitle: "TrustLink ouvre les portes du marché béninois aux grossistes nigérians, sans les tracas logistiques ou monétaires.",
      cards: [
        { 
          icon: <BarChart3 className="text-blue-600" size={32} />, 
          t: "Paiements Garantis en Naira", 
          d: "Fini l'incertitude du change. Recevez vos fonds directement en Naira dès la collecte des produits." 
        },
        { 
          icon: <ShieldCheck className="text-blue-600" size={32} />, 
          t: "Zéro Logistique pour Vous", 
          d: "Nous gérons tout : de la collecte dans votre boutique à Lagos jusqu'à la livraison finale au Bénin." 
        },
        { 
          icon: <Truck className="text-blue-600" size={32} />, 
          t: "Expansion de Marché", 
          d: "Touchez des milliers de nouveaux acheteurs professionnels au Bénin sans quitter votre boutique au Nigeria." 
        }
      ]
    },
    en: {
      title: "Why Sell with ",
      span: "TrustLink?",
      subtitle: "TrustLink opens the doors of the Beninese market to Nigerian wholesalers, without logistical or monetary hassles.",
      cards: [
        { 
          icon: <BarChart3 className="text-blue-600" size={32} />, 
          t: "Guaranteed Naira Payouts", 
          d: "No more currency uncertainty. Receive your funds directly in Naira as soon as products are collected." 
        },
        { 
          icon: <ShieldCheck className="text-blue-600" size={32} />, 
          t: "Zero Logistics for You", 
          d: "We handle everything: from pickup at your shop in Lagos to final delivery in Benin." 
        },
        { 
          icon: <Truck className="text-blue-600" size={32} />, 
          t: "Market Expansion", 
          d: "Reach thousands of new professional buyers in Benin without leaving your shop in Nigeria." 
        }
      ]
    }
  }[lang];

  return (
    <section id="features" className="py-24 bg-slate-50">
      <div className="container mx-auto px-6">
        <div className="max-w-3xl mb-16">
          <h2 className="text-3xl md:text-5xl font-black text-slate-900 mb-6">
            {t.title} <span className="text-blue-600">{t.span}</span>
          </h2>
          <p className="text-xl text-slate-500 leading-relaxed">
            {t.subtitle}
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {t.cards.map((card: any, i: number) => (
            <div key={i} className="bg-white p-10 rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-xl transition-all group">
              <div className="mb-6 group-hover:scale-110 transition-transform duration-500">{card.icon}</div>
              <h3 className="text-xl font-bold text-slate-900 mb-4">{card.t}</h3>
              <p className="text-slate-500 text-sm leading-relaxed">{card.d}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
