import React from 'react';
import { Building2, MessageSquare, Mail, Phone, MapPin } from 'lucide-react';

interface FooterProps {
  lang: 'fr' | 'en';
}

const Footer: React.FC<FooterProps> = ({ lang }) => {
  const t = {
    fr: {
      desc: "L'infrastructure d'exportation de confiance reliant les grossistes nigérians au marché béninois.",
      office_lagos: "Bureau Lagos : Ikeja",
      office_cotonou: "Bureau Cotonou : Ganhi",
      links: "Liens Rapides",
      contact: "Contactez-nous",
      rights: "Tous droits réservés."
    },
    en: {
      desc: "The trusted export infrastructure connecting Nigerian wholesalers to the Beninese market.",
      office_lagos: "Lagos Office: Ikeja",
      office_cotonou: "Cotonou Office: Ganhi",
      links: "Quick Links",
      contact: "Contact Us",
      rights: "All rights reserved."
    }
  }[lang];

  return (
    <footer className="bg-slate-900 text-slate-400 py-20">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="space-y-6">
            <div className="flex items-center gap-2 text-white">
              <img 
                src="https://raw.githubusercontent.com/Tobi-Ag/TrustLink-Assets/main/logo.png" 
                alt="TrustLink Logo" 
                className="h-10 w-auto brightness-0 invert"
                referrerPolicy="no-referrer"
              />
            </div>
            <p className="text-sm leading-relaxed max-w-xs">
              {t.desc}
            </p>
          </div>
          
          <div>
            <h4 className="text-white font-black uppercase tracking-widest text-xs mb-8">{t.links}</h4>
            <ul className="space-y-4 text-sm font-bold">
              <li><a href="#how" className="hover:text-blue-500 transition-colors">{lang === 'fr' ? 'Infrastructure' : 'Infrastructure'}</a></li>
              <li><a href="#features" className="hover:text-blue-500 transition-colors">{lang === 'fr' ? 'Avantages' : 'Benefits'}</a></li>
              <li><a href="#blog" className="hover:text-blue-500 transition-colors">{lang === 'fr' ? 'Intelligence' : 'Intelligence'}</a></li>
              <li><a href="#waitlist" className="hover:text-blue-500 transition-colors">{lang === 'fr' ? 'S\'inscrire' : 'Register'}</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-white font-black uppercase tracking-widest text-xs mb-8">{t.contact}</h4>
            <ul className="space-y-4 text-sm font-bold">
              <li className="flex items-center gap-3"><Mail size={16} className="text-blue-500" /> contact@trustlink.africa</li>
              <li className="flex items-center gap-3"><Phone size={16} className="text-blue-500" /> +234 800 TRUSTLINK</li>
              <li className="flex items-center gap-3"><MessageSquare size={16} className="text-blue-500" /> WhatsApp Support</li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-white font-black uppercase tracking-widest text-xs mb-8">Locations</h4>
            <ul className="space-y-4 text-sm font-bold">
              <li className="flex items-start gap-3"><MapPin size={16} className="text-blue-500 shrink-0" /> {t.office_lagos}</li>
              <li className="flex items-start gap-3"><MapPin size={16} className="text-blue-500 shrink-0" /> {t.office_cotonou}</li>
            </ul>
          </div>
        </div>
        
        <div className="pt-12 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center gap-6">
          <p className="text-xs font-bold uppercase tracking-widest">
            © {new Date().getFullYear()} TRUSTLINK TECHNOLOGIES. {t.rights}
          </p>
          <div className="flex gap-8 text-[10px] font-black uppercase tracking-widest">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
