import React, { useState } from 'react';
import { ArrowRight, CheckCircle2, Zap, Building2, ShieldCheck, Globe, Truck } from 'lucide-react';

interface VendorFormProps {
  lang: 'fr' | 'en';
}

const VendorForm: React.FC<VendorFormProps> = ({ lang }) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const t = {
    fr: {
      badge: "POUR LES VENDEURS NIGÉRIANS",
      title: "Vendez au Bénin, payé en ",
      span: "Naira instantanément.",
      desc: "TrustLink gère la logistique, la conversion de devises (CFA vers Naira) et la livraison. Concentrez-vous sur votre stock, nous vous apportons les commandes internationales.",
      benefit1_t: "Zéro Risque de Paiement",
      benefit1_d: "Recevez vos Naira dès que nous collectons les marchandises dans votre boutique.",
      benefit2_t: "Collecte Gratuite",
      benefit2_d: "Nos agents récupèrent les colis directement à Balogun, Alaba ou tout autre marché de Lagos.",
      benefit3_t: "Nouveau Marché Massif",
      benefit3_d: "Accédez à des milliers d'acheteurs en gros à Cotonou et Porto-Novo.",
      form_title: "Devenez un Vendeur Certifié",
      form_subtitle: "Remplissez le formulaire pour commencer à exporter avec TrustLink.",
      label_biz: "Nom de l'entreprise / Boutique",
      label_whatsapp: "Numéro WhatsApp",
      label_location: "Emplacement du Marché au Nigeria",
      label_cat: "Que vendez-vous ?",
      label_exported: "Avez-vous déjà vendu au Bénin ?",
      btn: "REJOINDRE LA LISTE D'ATTENTE",
      success_t: "Demande Reçue !",
      success_d: "Un agent de Lagos vous contactera sur WhatsApp sous 24h pour vérifier votre boutique.",
      disclaimer: "En rejoignant, vous acceptez de fournir des produits authentiques. TrustLink vérifie physiquement tous les vendeurs."
    },
    en: {
      badge: "FOR NIGERIAN VENDORS",
      title: "Sell to Benin, get paid in ",
      span: "Naira instantly.",
      desc: "TrustLink handles logistics, currency conversion (CFA to Naira), and delivery. You just focus on your stock, we bring you the international orders.",
      benefit1_t: "Zero Payment Risk",
      benefit1_d: "Get your Naira payout as soon as we pick up the goods from your shop.",
      benefit2_t: "Free Shop Pickup",
      benefit2_d: "Our agents collect items directly from your location in Balogun, Alaba, or any Lagos market.",
      benefit3_t: "Massive New Market",
      benefit3_d: "Access thousands of bulk buyers from Cotonou and Porto-Novo looking for your products.",
      form_title: "Become a Verified Vendor",
      form_subtitle: "Fill the form below to start exporting with TrustLink.",
      label_biz: "Business / Shop Name",
      label_whatsapp: "WhatsApp Number",
      label_location: "Market Location in Nigeria",
      label_cat: "What do you sell?",
      label_exported: "Have you sold to Benin Republic before?",
      btn: "JOIN VENDOR WAITLIST",
      success_t: "Application Received!",
      success_d: "One of our Lagos agents will message you on WhatsApp within 24 hours to verify your shop.",
      disclaimer: "By joining, you agree to supply genuine products. TrustLink verifies all vendors physically."
    }
  }[lang];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
    }, 1500);
  };

  return (
    <section id="waitlist" className="py-24 bg-slate-50">
      <div className="container mx-auto px-6">
        <div className="flex flex-col lg:flex-row gap-16 items-start">
          
          {/* Left: Selling points for vendors */}
          <div className="lg:w-1/2">
            <div className="inline-block px-4 py-1 rounded-full bg-blue-100 text-blue-700 text-xs font-bold mb-6">
              {t.badge}
            </div>
            <h2 className="text-4xl md:text-6xl font-black leading-tight mb-6">
              {t.title} <span className="text-blue-600">{t.span}</span>
            </h2>
            <p className="text-xl text-slate-600 mb-10 leading-relaxed">
              {t.desc}
            </p>

            <div className="space-y-8">
              <div className="flex gap-4">
                <div className="w-12 h-12 bg-white rounded-2xl shadow-sm flex items-center justify-center text-blue-600 shrink-0">
                  <ShieldCheck size={24} />
                </div>
                <div>
                  <h3 className="font-bold text-lg">{t.benefit1_t}</h3>
                  <p className="text-slate-500">{t.benefit1_d}</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="w-12 h-12 bg-white rounded-2xl shadow-sm flex items-center justify-center text-blue-600 shrink-0">
                  <Truck size={24} />
                </div>
                <div>
                  <h3 className="font-bold text-lg">{t.benefit2_t}</h3>
                  <p className="text-slate-500">{t.benefit2_d}</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="w-12 h-12 bg-white rounded-2xl shadow-sm flex items-center justify-center text-orange-600 shrink-0">
                  <Globe size={24} />
                </div>
                <div>
                  <h3 className="font-bold text-lg">{t.benefit3_t}</h3>
                  <p className="text-slate-500">{t.benefit3_d}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right: The Form */}
          <div className="lg:w-1/2 w-full">
            <div className="bg-white p-8 md:p-10 rounded-[2.5rem] shadow-2xl border border-slate-100 relative overflow-hidden">
              {isSuccess ? (
                <div className="py-12 text-center animate-in fade-in zoom-in duration-500">
                  <div className="w-20 h-20 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-6 text-3xl">
                    <CheckCircle2 size={40} />
                  </div>
                  <h2 className="text-2xl font-bold mb-2">{t.success_t}</h2>
                  <p className="text-slate-500 mb-8">{t.success_d}</p>
                  <button 
                    onClick={() => setIsSuccess(false)}
                    className="text-blue-600 font-bold hover:underline"
                  >
                    {lang === 'fr' ? "Soumettre une autre entreprise" : "Submit another business"}
                  </button>
                </div>
              ) : (
                <>
                  <div className="mb-8">
                    <h2 className="text-2xl font-bold mb-2">{t.form_title}</h2>
                    <p className="text-slate-500">{t.form_subtitle}</p>
                  </div>

                  <form onSubmit={handleSubmit} className="space-y-5">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                      <div>
                        <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">{t.label_biz}</label>
                        <input 
                          required
                          type="text" 
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                          placeholder="e.g. Ade Wholesale Ventures"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">{t.label_whatsapp}</label>
                        <div className="relative">
                          <span className="absolute left-4 top-1/2 -translate-y-1/2 text-sm font-bold text-slate-400">+234</span>
                          <input 
                            required
                            type="tel" 
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-14 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                            placeholder="8012345678"
                          />
                        </div>
                      </div>
                    </div>

                    <div>
                      <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">{t.label_location}</label>
                      <select className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all cursor-pointer">
                        <option>Balogun Market (Lagos)</option>
                        <option>Alaba International (Lagos)</option>
                        <option>Trade Fair (Lagos)</option>
                        <option>Onitsha Main Market</option>
                        <option>Kano Market</option>
                        <option>Other / Private Warehouse</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">{t.label_cat}</label>
                      <select className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all cursor-pointer">
                        <option>Fashion & Textiles</option>
                        <option>Electronics & Gadgets</option>
                        <option>Beauty & Cosmetics</option>
                        <option>Auto Parts</option>
                        <option>Home Goods</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">{t.label_exported}</label>
                      <div className="flex gap-6 mt-2">
                        <label className="flex items-center gap-2 cursor-pointer group">
                          <input type="radio" name="exported" value="yes" className="w-4 h-4 accent-blue-600" />
                          <span className="text-sm font-bold text-slate-600 group-hover:text-blue-600 transition-colors">{lang === 'fr' ? 'Oui' : 'Yes'}</span>
                        </label>
                        <label className="flex items-center gap-2 cursor-pointer group">
                          <input type="radio" name="exported" value="no" defaultChecked className="w-4 h-4 accent-blue-600" />
                          <span className="text-sm font-bold text-slate-600 group-hover:text-blue-600 transition-colors">{lang === 'fr' ? 'Non, je veux commencer' : 'No, I want to start'}</span>
                        </label>
                      </div>
                    </div>

                    <button 
                      disabled={isSubmitting}
                      type="submit"
                      className="w-full bg-blue-600 text-white font-black py-4 rounded-xl hover:bg-blue-700 transition-all shadow-lg shadow-blue-100 flex items-center justify-center gap-2 mt-4 disabled:opacity-70"
                    >
                      {isSubmitting ? "..." : t.btn} <ArrowRight size={20} />
                    </button>

                    <p className="text-[10px] text-center text-slate-400 mt-4 italic">
                      {t.disclaimer}
                    </p>
                  </form>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default VendorForm;
